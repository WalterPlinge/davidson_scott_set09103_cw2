# Napier Coursework Article Latex Template
### Copyright (C) 2016  Edinburgh Napier University

## Requirements
* Non Free Fonts
    * http://tug.org/fonts/getnonfreefonts/
    * `wget -q http://tug.org/fonts/getnonfreefonts/install-getnonfreefonts`
    * `sudo texlua ./install-getnonfreefonts`
    * `getnonfreefonts -a`
* algorithm2e
    * `tlmgr install algorithm2e`

## Building
### Linux
* Install dependencies as above
* `make`
